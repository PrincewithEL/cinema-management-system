
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Asher (137187)
 */
public abstract class DBConnection {   
   
    
     Connection con = connect();
     
     public Connection connect(){
        //a connection scenario with the database
           
        Connection connect;
        
        //attempt to see if the driver is working
        try{
            Class.forName("com.mysql.jdbc.Driver");
            //verification for success in attempt
            System.out.println("Connection to the Database is Successful");
        }catch(ClassNotFoundException cnfe){
            //verification for failure in attempt
            System.out.println("Error finding class : "+cnfe.getMessage());
        }
        
        //establish a connection to the database
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cinema_management_system","root","");
            //verification for success in connection
            System.out.println("Connection to the Database is Successful");
        }catch(SQLException sqle){
            //verification for failure in connection
            System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
        }
        
        return con;
    }
     
     public DBConnection(){
          //attempt to see if the driver is working
        try{
            Class.forName("com.mysql.jdbc.Driver");
            //verification for success in attempt
            System.out.println("Connection to the Database is Successful");
        }catch(ClassNotFoundException cnfe){
            //verification for failure in attempt
            System.out.println("Error finding class : "+cnfe.getMessage());
        }
        
        //establish a connection to the database
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cinema_management_system","root","");
            //verification for success in connection
            System.out.println("Connection to the Database is Successful");
        }catch(SQLException sqle){
            //verification for failure in connection
            System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
        }
     }
     
     public abstract void insertOperation(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9);
 
     public abstract void selectOperation(String s);
     
     public abstract void deleteOperation(String s);
     
     public abstract void updateOperation(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10);
     
     public abstract void insertOperation1(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8);
 
     public abstract void selectOperation1(String s);
     
     public abstract void deleteOperation1(String s);
     
     public abstract void updateOperation1(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9);
     
     public abstract void insertOperation2(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9);
 
     public abstract void selectOperation2(String s);
     
     public abstract void deleteOperation2(String s);
     
     public abstract void updateOperation2(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10);

}
