import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.*;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Callback;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asher (137187)
 */

public class dashboard extends Application {
 Connection con;
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        //HOMEPAGE SECTION
        //Homepage Dashboard
        //Homepage HCI Text
        Label kindly = new Label();
        kindly.setText("Kindly select an option to proceed: ");
        kindly.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Homepage Buttons
        Button btn1 = new Button();
        btn1.setText("Movies");
        btn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn1.setTextFill(Color.BLUE);
        Button btn2 = new Button();
        btn2.setText("Customers");
        btn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn2.setTextFill(Color.BLUE);
        Button btn3 = new Button();
        btn3.setText("Staff");
        btn3.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn3.setTextFill(Color.BLUE);
        Button byebtn = new Button();
        byebtn.setText("Exit");
        byebtn.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        byebtn.setTextFill(Color.RED);
        //Homepage Images
        //creating the image object
        InputStream stream = new FileInputStream("F:\\Pictures\\logo.png");
        Image image = new Image(stream);
        //Creating the image view
        ImageView imageView = new ImageView();
        //Setting image to the image view
        imageView.setImage(image);
        //Setting the image view parameters
        imageView.setX(10);
        imageView.setY(10);
        imageView.setFitWidth(700);
        imageView.setPreserveRatio(true);
        //Homepage VBOX
        VBox home = new VBox(20);
        //CSS for Main Layout
        String cssLayout = "-fx-border-color: blue;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 3;\n" +
                    "-fx-background-color : linear-gradient(yellow, cyan, blue);"+
                   "-fx-border-style: solid;\n";
        //Set CSS
        home.setStyle(cssLayout);
        //Set Alignment
        home.setAlignment(Pos.CENTER);
        //Homepage Scene
        Scene scene1 = new Scene(home, 900, 800);
        //Set Homepage to Primary Stage
        primaryStage.setTitle("The Cinema Management System");
        primaryStage.setScene(scene1);
        primaryStage.show();
        //Get Children/Elements for the Homepage
        home.getChildren().addAll(imageView, kindly, btn1, btn2, btn3, byebtn);
        
        //MOVIE SECTION
        //Movie VBOX
        VBox movie = new VBox(20);
        movie.setAlignment(Pos.CENTER);
        //Movie Scene
        Scene scene2 = new Scene(movie, 900, 800);
        //BackgroundFill background_fill1 = new BackgroundFill(Color.TOMATO, CornerRadii.EMPTY, Insets.EMPTY);
        //Background background1 = new Background(background_fill1);
        //movie.setBackground(background1);
        //Movie Page
        //Movie Title
        //Homepage Images
        //creating the image object
        InputStream stream1 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image1 = new Image(stream1);
        //Creating the image view
        ImageView imageView1 = new ImageView();
        //Setting image to the image view
        imageView1.setImage(image1);
        //Setting the image view parameters
        imageView1.setX(10);
        imageView1.setY(10);
        imageView1.setFitWidth(700);
        imageView1.setPreserveRatio(true);
        //Movie HCI Text
        Label kindly1 = new Label();
        kindly1.setText("Kindly select an option to proceed : ");
        kindly1.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Insert Movie Buttons
        Button btn4 = new Button();
        btn4.setText("Insert A New Movie");
        btn4.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn4.setTextFill(Color.BLUE);
        Button btn5 = new Button();
        btn5.setText("Delete A Movie");
        btn5.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn5.setTextFill(Color.BLUE);
        Button btn6 = new Button();
        btn6.setText("Update A Movie");
        btn6.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn6.setTextFill(Color.BLUE);
        Button btn7 = new Button();
        btn7.setText("Select A Movie");
        btn7.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn7.setTextFill(Color.BLUE);
        Button viewbtn1 = new Button();
        viewbtn1.setText("View Movies");
        viewbtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        viewbtn1.setTextFill(Color.BLUE);
        Button backbtn1 = new Button();
        backbtn1.setText("Return");
        backbtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn1.setTextFill(Color.RED);
        //Action to Set Scene to Homepage when Return Button on Movie Page is Clicked
        backbtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene1);
            primaryStage.show();         
            }
        });
        //Set Style
        movie.setStyle(cssLayout);
        //Get Children/Elements for Movie Page
        movie.getChildren().addAll(imageView1, kindly1, btn4, btn5, btn6, btn7, viewbtn1, backbtn1);
        //Action to Set Scene to Movie Page when Movie Button on Homepage is Clicked
         btn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene2);
            primaryStage.show();
            }
        });
        
        //Insert A Movie GRID BOX
        GridPane minsert = new GridPane();
        minsert.setHgap(30);
        minsert.setVgap(30);
        minsert.setPadding(new Insets(20));
        //Insert A Movie Scene
        Scene scene3 = new Scene(minsert, 900, 1000);
        //Insert A Movie Page
        //Insert A Movie NAvigation Buttons
        Button navbtn1 = new Button();
        navbtn1.setText("Insert A New Movie");
        navbtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        navbtn1.setTextFill(Color.BLUE);
        Button navbtn2 = new Button();
        navbtn2.setText("Delete A Movie");
        navbtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        navbtn2.setTextFill(Color.BLUE);
        Button navbtn3 = new Button();
        navbtn3.setText("Update A Movie");
        navbtn3.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        navbtn3.setTextFill(Color.BLUE);
        Button navbtn4 = new Button();
        navbtn4.setText("Select A Movie");
        navbtn4.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        navbtn4.setTextFill(Color.BLUE);
        Button navbtn5 = new Button();
        navbtn5.setText("View Movies");
        navbtn5.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        navbtn5.setTextFill(Color.BLUE);
        //Insert A Movie Images
        //creating the image object
        InputStream stream3 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image3 = new Image(stream3);
        //Creating the image view
        ImageView imageView3 = new ImageView();
        //Setting image to the image view
        imageView3.setImage(image3);
        //Setting the image view parameters
        imageView3.setX(10);
        imageView3.setY(10);
        imageView3.setFitWidth(700);
        imageView3.setPreserveRatio(true);
        //Insert A Movie HCI Text
        Label kindly2 = new Label();
        kindly2.setText("Kindly fill the fields below to insert a movie : ");
        kindly2.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));     
        Label date1 = new Label();
        date1.setText("Date Added : ");
        date1.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label date2 = new Label();
        date2.setText("Showing Date Start : ");
        date2.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label date3 = new Label();
        date3.setText("Showing Date End : ");
        date3.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Insert A Movie TextFields
        TextField insert1 = new TextField();
        insert1.setPromptText("Input Movie Name");
        insert1.setFocusTraversable(false); 
        TextField insert2 = new TextField();
        TextField insert3 = new TextField();
        TextField insert4 = new TextField();
        TextField insert5 = new TextField();
        insert5.setPromptText("Input Movie Studio");
        insert5.setFocusTraversable(false); 
        TextField insert6 = new TextField();
        insert6.setPromptText("Input Movie Suppliers");
        insert6.setFocusTraversable(false); 
        TextField insert7 = new TextField();
        insert7.setPromptText("Input Movie Runtime (in Minutes)");
        insert7.setFocusTraversable(false); 
        TextField insert8 = new TextField();
        insert8.setPromptText("Input Movie Genre");
        insert8.setFocusTraversable(false); 
        //Insert A Movie Date Pickers
        DatePicker datepick1 = new DatePicker();
        DatePicker datepick2 = new DatePicker();
        DatePicker datepick3 = new DatePicker();
        //Set Min AND/OR Max Dates
        final Callback<DatePicker, DateCell> dayCellFactory;
        DatePicker maxDate = new DatePicker();
        maxDate.setValue(LocalDate.now());
        dayCellFactory = (final DatePicker datePicker) -> new DateCell() {
        @Override
        public void updateItem(LocalDate item, boolean empty) {
        super.updateItem(item, empty);
        if (item.isBefore(maxDate.getValue())) { //Disable all dates after required date
            setDisable(true);
            setStyle("-fx-background-color: #ffc0cb;"); //To set background on different color
        }
        }
        };
        //Finally, we just need to update our DatePicker cell factory as follow:
        datepick1.setDayCellFactory(dayCellFactory);
        datepick2.setDayCellFactory(dayCellFactory);
        datepick3.setDayCellFactory(dayCellFactory);
        //Actions for Date To String Conversions
        datepick1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i1 = datepick1.getValue();
           insert2.setText(i1.toString());
            }
        });
        datepick2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i2 = datepick2.getValue();
           insert3.setText(i2.toString());
            }
        });
        datepick3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i3 = datepick3.getValue();
           insert4.setText(i3.toString());
            }
        });
        //Insert A Movie Combo-Boxes
        String form [] = {"2D", "3D", "4D", "7D"};
        ComboBox form1 = new ComboBox(FXCollections.observableArrayList(form));
        Label selected1 = new Label();
        selected1.setText("Select A Movie Format : ");
        selected1.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            selected.setText((String) form1.getValue());
            }
        };
        form1.setOnAction(event);
        //Insert A Movie Alert
        Alert a = new Alert(AlertType.NONE);
        //Insert A Movie Buttons
        Button backbtn2 = new Button();
        backbtn2.setText("Return");
        backbtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn2.setTextFill(Color.RED);
        backbtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

            primaryStage.setScene(scene2);
            primaryStage.show();         
            }
        });
        minsert.add(backbtn2, 0, 6);
        GridPane.setHalignment(backbtn2, HPos.CENTER);
        Button insertbtn = new Button();
        insertbtn.setText("Insert");
        insertbtn.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        insertbtn.setTextFill(Color.GREEN);
        //Action to Insert Data Into The Database
        insertbtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
        //Get String Values from required TextFields and Labels
                String mname = insert1.getText();
                String mdateadded = insert2.getText();
                String mshowingstart = insert3.getText();
                String mshowingend = insert4.getText();
                String mstudio = insert5.getText();
                String msupplier = insert6.getText();
                String mruntime = insert7.getText();
                String mgenre = insert8.getText();
                String mformat = selected.getText();
                
            a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Insert A Movie ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(insert1.getText().trim().isEmpty() || insert2.getText().trim().isEmpty() || insert3.getText().trim().isEmpty() || insert4.getText().trim().isEmpty() || insert5.getText().trim().isEmpty() || insert6.getText().trim().isEmpty() || insert7.getText().trim().isEmpty() || insert8.getText().trim().isEmpty() || selected.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
            a.setContentText("Kindly Ensure That All Fields Are Not Empty.");
            a.show();
         }else{
             DBOperations inc = new DBOperations();
             inc.insertOperation(mname,mdateadded,mshowingstart,mshowingstart,mstudio,msupplier,mformat,mgenre,mruntime);
             insert1.clear();
             insert2.clear();
             insert3.clear();
             insert4.clear();
             insert5.clear();
             insert6.clear();
             insert7.clear();
             insert8.clear();
             selected.clear();
             form1.setValue(null);
             datepick1.setValue(null);
             datepick2.setValue(null);
             datepick3.setValue(null);
             primaryStage.setScene(scene1);
             primaryStage.show();
         }
          }else if (result.get() == ButtonType.NO){  
            }
            }
        });
        //Set Style
        minsert.setStyle(cssLayout);
        //creating the image object
        InputStream stream20 = new FileInputStream("F:\\Pictures\\clapperboard.png");
        Image image20 = new Image(stream20);
        //Creating the image view
        ImageView imageView20 = new ImageView();
        //Setting image to the image view
        imageView20.setImage(image20);
        //Navigation Buttons
        navbtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene3);
            primaryStage.show();         
            }
        });
        //Setting the image view parameters
        imageView20.setX(10);
        imageView20.setY(10);
        imageView20.setFitWidth(350);
        imageView20.setPreserveRatio(true);
        //Get Children/Elements for Insert Movie Page
        minsert.add(imageView3, 0, 0, 4, 1);
        GridPane.setHalignment(imageView3, HPos.CENTER);
        
        minsert.add(kindly2, 1, 1, 2, 1);
        minsert.add(navbtn1, 0, 1);
        minsert.add(navbtn2, 0, 2);
        minsert.add(navbtn3, 0, 3);
        minsert.add(navbtn4, 0, 4);
        minsert.add(navbtn5, 0, 5);
        GridPane.setHalignment(navbtn1, HPos.CENTER);
        GridPane.setHalignment(navbtn2, HPos.CENTER);
        GridPane.setHalignment(navbtn3, HPos.CENTER);
        GridPane.setHalignment(navbtn4, HPos.CENTER);
        GridPane.setHalignment(navbtn5, HPos.CENTER);
        minsert.add(insert1, 1, 2);
        minsert.add(date1, 1, 3);
        minsert.add(datepick1, 1, 4);
        minsert.add(date2, 1, 5);
        minsert.add(datepick2, 1, 6);
        minsert.add(date3, 1, 7);
        minsert.add(datepick3, 1, 8);
        minsert.add(insert5, 2, 2);
        minsert.add(insert6, 2, 3);
        minsert.add(insert7, 2, 4);
        minsert.add(insert8, 2, 5);
        minsert.add(selected1, 2, 6);
        minsert.add(form1, 2, 7);
        minsert.add(insertbtn, 2, 8);
        minsert.add(imageView20, 3, 2, 1, 2);
        //minsert.getChildren().addAll(imageView3, kindly2, insert1, date1, datepick1, date2, datepick2, date3, datepick3, insert5, insert6, insert7, insert8, selected1, form1, insertbtn, backbtn2);
        //Action to Set Scene to Insert Movie Page when Insert Movie Button on Movie Page is Clicked
        btn4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene3);
            primaryStage.show();
            }
        });
        
        //Delete A Movie VBOX
        VBox mdelete = new VBox(15);
        mdelete.setAlignment(Pos.CENTER);
        //Delete A Movie Scene
        Scene scene4 = new Scene(mdelete, 900, 800);
        //Delete A Movie Page
        //Delete A Movie Images
        //creating the image object
        InputStream stream4 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image4 = new Image(stream4);
        //Creating the image view
        ImageView imageView4 = new ImageView();
        //Setting image to the image view
        imageView4.setImage(image4);
        //Setting the image view parameters
        imageView4.setX(10);
        imageView4.setY(10);
        imageView4.setFitWidth(700);
        imageView4.setPreserveRatio(true);
        //Delete A Movie HCI Text
        Label kindly3 = new Label();
        kindly3.setText("Kindly fill the field below to delete a movie : ");
        kindly3.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Delete A Movie TextFields
        TextField delete1 = new TextField();
        delete1.setPromptText("Input Movie ID");
        delete1.setFocusTraversable(false); 
        //Delete A Movie Buttons
        navbtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene4);
            primaryStage.show();         
            }
        });
        Button backbtn3 = new Button();
        backbtn3.setText("Return");
        backbtn3.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn3.setTextFill(Color.RED);
        backbtn3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene2);
            primaryStage.show();         
            }
        });
        Button deletebtn = new Button();
        deletebtn.setText("Delete");
        deletebtn.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        deletebtn.setTextFill(Color.GREEN);
        //Action to Delete Data From the Database
        deletebtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             
               String mid = delete1.getText();
                 a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Delete A Movie ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(delete1.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That The Movie ID Is Not Empty.");
           a.show();
         }else{
            DBOperations del = new DBOperations() {};
            del.deleteOperation(mid);
            delete1.clear();
            primaryStage.setScene(scene1);
            primaryStage.show();
            }
        }    
            }
        });
        //Set Style
        mdelete.setStyle(cssLayout);
        //Get Children/Elements for Delete Movie Page
        mdelete.getChildren().addAll(imageView4, kindly3, delete1, deletebtn, backbtn3);
        //Action to Set Scene to Delete Movie Page when Delete Movie Button on Movie Page is Clicked
        btn5.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene4);
            primaryStage.show();
            }
        });
        
        //UPDATE A Movie VBOX
        VBox mupdate = new VBox(10);
        mupdate.setAlignment(Pos.CENTER);
        //Update A Movie Scene
        Scene scene5 = new Scene(mupdate, 900, 1000);    
        //Update A Movie Page
        //Update A Movie Images
        //creating the image object
        InputStream stream5 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image5 = new Image(stream5);
        //Creating the image view
        ImageView imageView5 = new ImageView();
        //Setting image to the image view
        imageView5.setImage(image1);
        //Setting the image view parameters
        imageView5.setX(10);
        imageView5.setY(10);
        imageView5.setFitWidth(700);
        imageView5.setPreserveRatio(true);
        //Update A Movie HCI Text
        Label kindly4 = new Label();
        kindly4.setText("Kindly fill the fields below to update a Movie : ");
        kindly4.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Update A Movie TextFields
        TextField update1 = new TextField();
        update1.setPromptText("Input Existing Movie ID");
        update1.setFocusTraversable(false);
        TextField update2 = new TextField();
        update2.setPromptText("Input Movie Name");
        update2.setFocusTraversable(false); 
        TextField update3 = new TextField();
        TextField update4 = new TextField();
        TextField update5 = new TextField();
        TextField update6 = new TextField();
        update6.setPromptText("Input Movie Studio");
        update6.setFocusTraversable(false); 
        TextField update7 = new TextField();
        update7.setPromptText("Input Movie Suppliers");
        update7.setFocusTraversable(false); 
        TextField update8 = new TextField();
        update8.setPromptText("Input Movie Runtime (in Minutes)");
        update8.setFocusTraversable(false); 
        TextField update9 = new TextField();
        update9.setPromptText("Input Movie Genre");
        update9.setFocusTraversable(false); 
        Label date4 = new Label();
        date4.setText("Date Added : ");
        date4.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label date5 = new Label();
        date5.setText("Showing Date Start : ");
        date5.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label date6 = new Label();
        date6.setText("Showing Date End : ");
        date6.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Update A Movie Date Pickers
        DatePicker datepick4 = new DatePicker();
        DatePicker datepick5 = new DatePicker();
        DatePicker datepick6 = new DatePicker();
        //Set Min AND/OR Max Dates
        final Callback<DatePicker, DateCell> dayCellFactory1;
        DatePicker maxDate1 = new DatePicker();
        maxDate1.setValue(LocalDate.now());
        dayCellFactory1 = (final DatePicker datePicker) -> new DateCell() {
        @Override
        public void updateItem(LocalDate item, boolean empty) {
        super.updateItem(item, empty);
        if (item.isBefore(maxDate1.getValue())) { //Disable all dates after required date
            setDisable(true);
            setStyle("-fx-background-color: #ffc0cb;"); //To set background on different color
        }
        }
        };
        //Finally, we just need to update our DatePicker cell factory as follow:
        datepick4.setDayCellFactory(dayCellFactory);
        datepick5.setDayCellFactory(dayCellFactory);
        datepick6.setDayCellFactory(dayCellFactory);
        //Actions for Date To String Conversions
        datepick4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i4 = datepick4.getValue();
           update3.setText(i4.toString());
            }
        });
        datepick5.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i5 = datepick5.getValue();
           update4.setText(i5.toString());
            }
        });
        datepick6.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i6 = datepick6.getValue();
           update5.setText(i6.toString());
            }
        });
        //Insert A Movie Combo-Boxes
        String form2 [] = {"2D", "3D", "4D", "7D"};
        ComboBox form3 = new ComboBox(FXCollections.observableArrayList(form2));
        Label selected2 = new Label();
        selected2.setText("Select A Movie Format : ");
        selected2.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected3 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event1 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            selected3.setText((String) form3.getValue());
            }
        };
        form3.setOnAction(event1);
        //Update A Movie Buttons
        navbtn3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene5);
            primaryStage.show();         
            }
        });
        Button backbtn4 = new Button();
        backbtn4.setText("Return");
        backbtn4.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn4.setTextFill(Color.RED);
        backbtn4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene2);
            primaryStage.show();         
            }
        });
        Button updatebtn = new Button();
        updatebtn.setText("Update");
        updatebtn.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        updatebtn.setTextFill(Color.GREEN);
        //Action to Update A Movie 
        updatebtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                
                String mid = update1.getText();
                String mname = update2.getText();
                String mdateadded = update3.getText();
                String mshowingstart = update4.getText();
                String mshowingend = update5.getText();
                String mstudio = update6.getText();
                String msupplier = update7.getText();
                String mruntime = update8.getText();
                String mgenre = update9.getText();
                String mformat = selected3.getText();
       a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Update This Movie ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(update1.getText().trim().isEmpty() || update2.getText().trim().isEmpty() || update3.getText().trim().isEmpty() || update4.getText().trim().isEmpty() || update5.getText().trim().isEmpty() || update6.getText().trim().isEmpty() || update7.getText().trim().isEmpty() || update8.getText().trim().isEmpty() || update9.getText().trim().isEmpty() || selected3.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That All Fields Are Not Empty.");
           a.show();
         }else{          
           DBOperations upd = new DBOperations();
            upd.updateOperation(mid,mname,mdateadded,mshowingstart,mshowingend,mstudio,msupplier,mformat,mgenre,mruntime);
            update1.clear();
            update2.clear();
            update3.clear();
            update4.clear();
            update5.clear();
            update6.clear();
            update7.clear();
            update8.clear();
            update9.clear();
            selected3.clear();
            form3.setValue(null);
            datepick4.setValue(null);
            datepick5.setValue(null);
            datepick6.setValue(null);
            primaryStage.setScene(scene1);
            primaryStage.show();
            }
         }else if (result.get() == ButtonType.NO){  
            }
            }
        });
        //Set Style
        mupdate.setStyle(cssLayout);
        //Get Children/Elements for Update Movie Page
        mupdate.getChildren().addAll(imageView5, kindly4, update1, update2, date4, datepick4, date5, datepick5, date6, datepick6, update6, update7, update8, update9, selected2, form3, updatebtn, backbtn4);
        //Action to Set Scene to Update Movie Page when Update Movie Button on Movie Page is Clicked
         btn6.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene5);
            primaryStage.show();
            }
        });
        
        //SELECT A Movie VBOX
        VBox mselect = new VBox(10);
        mselect.setAlignment(Pos.CENTER);
        //Select A Movie Scene
        Scene scene6 = new Scene(mselect, 900, 1000);
        //Select A Movie Page
        //Select A Movie Title
        InputStream stream6 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image6 = new Image(stream6);
        //Creating the image view
        ImageView imageView6 = new ImageView();
        //Setting image to the image view
        imageView6.setImage(image6);
        //Setting the image view parameters
        imageView6.setX(10);
        imageView6.setY(10);
        imageView6.setFitWidth(700);
        imageView6.setPreserveRatio(true);
        //Select A Movie HCI Text
        Label kindly5 = new Label();
        kindly5.setText("Kindly fill in the field below to select a movie : ");
        kindly5.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Select A Movie TextField
        TextField select1 = new TextField();
        select1.setPromptText("Input Existing Movie ID");
        select1.setFocusTraversable(false);
        //Select A Movie Labels
        Label selection1 = new Label();
        selection1.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection2 = new Label();
        selection2.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection3 = new Label();
        selection3.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection4 = new Label();
        selection4.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection5 = new Label();
        selection5.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection6 = new Label();
        selection6.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection7 = new Label();
        selection7.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection8 = new Label();
        selection8.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection9 = new Label();
        selection9.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection10 = new Label();
        selection10.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Select A Movie Buttons
        navbtn4.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene6);
            primaryStage.show();         
            }
        });
        Button backbtn5 = new Button();
        backbtn5.setText("Return");
        backbtn5.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn5.setTextFill(Color.RED);
        backbtn5.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
           selection1.setText("");
           selection2.setText("");
           selection3.setText("");
           selection4.setText("");
           selection5.setText("");
           selection6.setText("");
           selection7.setText("");
           selection8.setText("");
           selection9.setText("");
           selection10.setText("");
           select1.clear();
           primaryStage.setScene(scene2);
           primaryStage.show();         
           }
        });
        Button selectbtn = new Button();
        selectbtn.setText("Select");
        selectbtn.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        selectbtn.setTextFill(Color.GREEN);
        //Action to Select A Movie 
        selectbtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             
                String mid = select1.getText();
                 a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Select This Movie ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(select1.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That Movie ID is Not Empty.");
           a.show();
         }else{     
           DBOperations sel = new DBOperations();
           sel.selectOperation(mid);
           selection1.setText("Movie ID : "+sel.mid1);
           selection2.setText("Movie Name : "+sel.mname);
           selection3.setText("Date Added : "+sel.mdateadded);
           selection4.setText("Showing Start : "+sel.mshowingstart);
           selection5.setText("Showing End : "+sel.mshowingend);
           selection6.setText("Movie Studio : "+sel.mstudio);
           selection7.setText("Movie Suppliers : "+sel.msupplier);
           selection8.setText("Movie Format : "+sel.mformat);
           selection9.setText("Movie Genre : "+sel.mgenre);
           selection10.setText("Movie Runtime : "+sel.mruntime);
           }
        }
         }
        });
        //Set Style
        mselect.setStyle(cssLayout);
        mselect.getChildren().addAll(imageView6, kindly5, select1, selectbtn, backbtn5, selection1, selection2, selection3, selection4, selection5, selection6, selection7, selection8, selection9, selection10);

        btn7.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene6);
            primaryStage.show();
            }
        }); 
        
          
        //View Movies VBOX
        VBox vmovie = new VBox(20);
        vmovie.setAlignment(Pos.CENTER);
        //View Movies Scene
        Scene scene17 = new Scene(vmovie, 900, 1000);
        //TableView for Movies
        TableView table = new TableView();
        //View Movies Button
        navbtn5.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene17);
            primaryStage.show();         
            }
        });
        Button backbtn16 = new Button();
        backbtn16.setText("Return");
        backbtn16.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn16.setTextFill(Color.RED);
        //View Movies Images
        InputStream stream7 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image7 = new Image(stream7);
        //Creating the image view
        ImageView imageView7 = new ImageView();
        //Setting image to the image view
        imageView7.setImage(image7);
        //Setting the image view parameters
        imageView7.setX(10);
        imageView7.setY(10);
        imageView7.setFitWidth(700);
        imageView7.setPreserveRatio(true);
        //View Movies HCI Text
        Label kindly16 = new Label();
        kindly16.setText("Below are the movies within our system: ");
        kindly16.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));

         ObservableList<ObservableList> data;
         Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/cinema_management_system","root","");
         data = FXCollections.observableArrayList();
        String tablelayout = "-fx-text-background-color: blue;";
        table.setStyle(tablelayout);
        vmovie.setStyle(cssLayout);
        vmovie.getChildren().addAll(imageView7, kindly16, table, backbtn16);
        viewbtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 try{
            Class.forName("com.mysql.jdbc.Driver");
            //SQL FOR SELECTING ALL OF MOVIES
            String SQL = "SELECT * FROM movies";
            //ResultSet
            ResultSet rs = c.createStatement().executeQuery(SQL);
            //TABLE COLUMN ADDED DYNAMICALLY 
            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                //We are using non property style for making dynamic table
                final int j = i;                
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
                        return new SimpleStringProperty(param.getValue().get(j).toString());                        
                    }                    
                });

                table.getColumns().addAll(col); 
                //System.out.println("Column ["+i+"] ");
            }
            //Data added to ObservableList *
            while(rs.next()){
                //Iterate Row
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                //System.out.println("Row [1] added "+row );
                data.add(row);

            }

            //FINALLY ADDED TO TableView
            table.setItems(data);
          }catch(Exception e){
              e.printStackTrace();
              System.out.println("Error on Building Data");             
          }
            primaryStage.setScene(scene17);
            primaryStage.show();         
            }
        });
        
              backbtn16.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            table.getColumns().clear();
            table.getItems().clear();
            primaryStage.setScene(scene2);
            primaryStage.show();         
            }
        });
      
        //CUSTOMER SECTION
        //Customer VBOX
        VBox customer = new VBox(20);
        customer.setAlignment(Pos.CENTER);
        //Customer Scene
        Scene scene7 = new Scene(customer, 900, 800);
        //Customer Page
        //Customer Images
        InputStream stream8 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image8 = new Image(stream8);
        //Creating the image view
        ImageView imageView8 = new ImageView();
        //Setting image to the image view
        imageView8.setImage(image8);
        //Setting the image view parameters
        imageView8.setX(10);
        imageView8.setY(10);
        imageView8.setFitWidth(700);
        imageView8.setPreserveRatio(true);
        //Customer HCI Text
        Label kindly6 = new Label();
        kindly6.setText("Kindly select an option to proceed : ");
        kindly6.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Insert Customer Buttons
        Button btn8 = new Button();
        btn8.setText("Insert A New Customer");
        btn8.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn8.setTextFill(Color.BLUE);
        Button btn9 = new Button();
        btn9.setText("Delete A Customer");
        btn9.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn9.setTextFill(Color.BLUE);
        Button btn10 = new Button();
        btn10.setText("Update A Customer");
        btn10.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn10.setTextFill(Color.BLUE);
        Button btn11 = new Button();
        btn11.setText("Select A Customer");
        btn11.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn11.setTextFill(Color.BLUE);
        Button viewbtn2 = new Button();
        viewbtn2.setText("View Customers");
        viewbtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        viewbtn2.setTextFill(Color.BLUE);
        Button backbtn6 = new Button();
        backbtn6.setText("Return");
        backbtn6.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn6.setTextFill(Color.RED);
        //Action to Set Scene to Homepage when Return Button on Customer Page is Clicked
        backbtn6.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene1);
            primaryStage.show();         
            }
        });
        //Set Style
        customer.setStyle(cssLayout);
        //Get Children/Elements for Customer Page
        customer.getChildren().addAll(imageView8, kindly6, btn8, btn9, btn10, btn11, viewbtn2, backbtn6);
        //Action to Set Scene to Customer Page when Customer Button on Homepage is Clicked
         btn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene7);
            primaryStage.show();
            }
        });
        
        //Insert A Customer VBOX
        VBox cinsert = new VBox(10);
        cinsert.setAlignment(Pos.CENTER);
        //Insert A Customer Scene
        Scene scene8 = new Scene(cinsert, 900, 1000);
        //Insert A Customer Page
        //Insert A Customer Images
        InputStream stream9 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image9 = new Image(stream9);
        //Creating the image view
        ImageView imageView9 = new ImageView();
        //Setting image to the image view
        imageView9.setImage(image9);
        //Setting the image view parameters
        imageView9.setX(10);
        imageView9.setY(10);
        imageView9.setFitWidth(700);
        imageView9.setPreserveRatio(true);
        //Insert A Customer HCI Text
        Label kindly7 = new Label();
        kindly7.setText("Kindly fill the fields below to insert a Customer : ");
        kindly7.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label date7 = new Label();
        date7.setText("Date Last Visited : ");
        date7.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Insert A Customer TextFields
        TextField insert9 = new TextField();
        insert9.setPromptText("Input First Name");
        insert9.setFocusTraversable(false); 
        TextField insert10 = new TextField();
        TextField insert11 = new TextField();
        insert11.setPromptText("Input Last Name");
        insert11.setFocusTraversable(false); 
        TextField insert12 = new TextField();
        insert12.setPromptText("Input Email Address");
        insert12.setFocusTraversable(false); 
        TextField insert13 = new TextField();
        insert13.setPromptText("Input Phone Number");
        insert13.setFocusTraversable(false); 
        TextField insert14 = new TextField();
        insert14.setPromptText("Input Bookings");
        insert14.setFocusTraversable(false); 
        //Insert A Customer Date Pickers
        DatePicker datepick7 = new DatePicker();
        //Set Min AND/OR Max Dates
        final Callback<DatePicker, DateCell> dayCellFactory2;
        DatePicker maxDate2 = new DatePicker();
        maxDate2.setValue(LocalDate.now());
        dayCellFactory2 = (final DatePicker datePicker) -> new DateCell() {
        @Override
        public void updateItem(LocalDate item, boolean empty) {
        super.updateItem(item, empty);
        if (item.isBefore(maxDate2.getValue())) { //Disable all dates after required date
            setDisable(true);
            setStyle("-fx-background-color: #ffc0cb;"); //To set background on different color
        }
        }
        };
        //Finally, we just need to update our DatePicker cell factory as follow:
        datepick7.setDayCellFactory(dayCellFactory2);
        //Actions for Date To String Conversions
        datepick7.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i7 = datepick7.getValue();
           insert10.setText(i7.toString());
            }
        });
        //Insert A Customer Combo-Boxes
        String form4 [] = {"CASH", "M-PESA", "CARD"};
        ComboBox form5 = new ComboBox(FXCollections.observableArrayList(form4));
        Label selected4 = new Label();
        selected4.setText("Select A Preffered Payment Type : ");
        selected4.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected5 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event2 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event2) {
            selected5.setText((String) form5.getValue());
            }
        };
        form5.setOnAction(event2);
        //Insert A Customer Combo-Boxes
        String form6 [] = {"Male", "Female"};
        ComboBox form7 = new ComboBox(FXCollections.observableArrayList(form6));
        Label selected6 = new Label();
        selected6.setText("Select A Gender : ");
        selected6.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected7 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event3 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event3) {
            selected7.setText((String) form7.getValue());
            }
        };
        form7.setOnAction(event3);
        //Insert A Customer Buttons
        Button backbtn7 = new Button();
        backbtn7.setText("Return");
        backbtn7.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn7.setTextFill(Color.RED);
        backbtn7.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene7);
            primaryStage.show();         
            }
        });
        Button insertbtn1 = new Button();
        insertbtn1.setText("Insert");
        insertbtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        insertbtn1.setTextFill(Color.GREEN);
        //Action to Insert Data Into The Database
        insertbtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
        //Get String Values from required TextFields and Labels
                String cfname = insert9.getText();
                String clname = insert11.getText();
                String cemail = insert12.getText();
                String cphone = insert13.getText();
                String clastvisited = insert10.getText();
                String cbookings = insert14.getText();
                String cpayments = selected5.getText();
                String cgender = selected7.getText();
                
            a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Insert A Movie ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(insert9.getText().trim().isEmpty() || insert10.getText().trim().isEmpty() || insert11.getText().trim().isEmpty() || insert12.getText().trim().isEmpty() || insert13.getText().trim().isEmpty() || insert14.getText().trim().isEmpty() || selected5.getText().trim().isEmpty() || selected7.getText().trim().isEmpty()){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Kindly Ensure That All Fields Are Not Empty.");
            a.show();
         }else if(!cemail.contains("@")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains @.");
            a.show();
        } else if(!cemail.contains(".com")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains .com.");
            a.show();
        }else{
             DBOperations inc = new DBOperations();
             inc.insertOperation1(cfname,clname,cemail,cphone,clastvisited,cbookings,cpayments,cgender);
             insert9.clear();
             insert10.clear();
             insert11.clear();
             insert12.clear();
             insert13.clear();
             insert14.clear();
             selected5.clear();
             selected7.clear();
             form5.setValue(null);
             form7.setValue(null);
             datepick7.setValue(null);
             primaryStage.setScene(scene1);
             primaryStage.show();
         }
          }else if (result.get() == ButtonType.NO){  
            }
            }
        });
        //Set Style
        cinsert.setStyle(cssLayout);
        //Get Children/Elements for Insert Customer Page
        cinsert.getChildren().addAll(imageView9, kindly7, insert9, insert11, date7, datepick7, insert12, insert13, insert14, selected4, form5, selected6, form7, insertbtn1, backbtn7);
        //Action to Set Scene to Insert Customer Page when Insert Customer Button on Customer Page is Clicked
        btn8.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene8);
            primaryStage.show();
            }
        });
        
        //Delete A Customer VBOX
        VBox cdelete = new VBox(15);
        cdelete.setAlignment(Pos.CENTER);
        //Delete A Customer Scene
        Scene scene9 = new Scene(cdelete, 900, 800);
        //Delete A Customer Page
        //Delete A Customer Images
        InputStream stream10 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image10 = new Image(stream10);
        //Creating the image view
        ImageView imageView10 = new ImageView();
        //Setting image to the image view
        imageView10.setImage(image10);
        //Setting the image view parameters
        imageView10.setX(10);
        imageView10.setY(10);
        imageView10.setFitWidth(700);
        imageView10.setPreserveRatio(true);
        //Delete A Customer HCI Text
        Label kindly8 = new Label();
        kindly8.setText("Kindly fill the field below to delete a customer : ");
        kindly8.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Delete A Customer TextFields
        TextField delete2 = new TextField();
        delete2.setPromptText("Input Customer ID");
        delete2.setFocusTraversable(false); 
        //Delete A Customer Buttons
        Button backbtn8 = new Button();
        backbtn8.setText("Return");
        backbtn8.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn8.setTextFill(Color.RED);
        backbtn8.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene7);
            primaryStage.show();         
            }
        });
        Button deletebtn1 = new Button();
        deletebtn1.setText("Delete");
        deletebtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        deletebtn1.setTextFill(Color.GREEN);
        //Action to Delete Data From the Database
        deletebtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             
               String cid = delete2.getText();
                 a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Delete A Customer ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(delete2.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That The Customer ID Is Not Empty.");
           a.show();
         }else{
            DBOperations del = new DBOperations() {};
            del.deleteOperation1(cid);
            delete2.clear();
            primaryStage.setScene(scene1);
            primaryStage.show();
            }
        }else if (result.get() == ButtonType.NO){  
            }    
            }
        });
        //Set Style
        cdelete.setStyle(cssLayout);
        //Get Children/Elements for Delete Customer Page
        cdelete.getChildren().addAll(imageView10, kindly8, delete2, deletebtn1, backbtn8);
        //Action to Set Scene to Delete Customer Page when Delete Customer Button on Customer Page is Clicked
        btn9.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene9);
            primaryStage.show();
            }
        });
        
        //UPDATE A Customer VBOX
        VBox cupdate = new VBox(10);
        cupdate.setAlignment(Pos.CENTER);
        //Update A Customer Scene
        Scene scene10 = new Scene(cupdate, 900, 1000);    
        //Update A Customer Page
        //Update A Customer Images
        InputStream stream11 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image11 = new Image(stream11);
        //Creating the image view
        ImageView imageView11 = new ImageView();
        //Setting image to the image view
        imageView11.setImage(image11);
        //Setting the image view parameters
        imageView11.setX(10);
        imageView11.setY(10);
        imageView11.setFitWidth(700);
        imageView11.setPreserveRatio(true);
        //Update A Customer HCI Text
        Label kindly9 = new Label();
        kindly9.setText("Kindly fill the fields below to update a Customer : ");
        kindly9.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Update A Customer TextFields
        TextField update10 = new TextField();
        update10.setPromptText("Input Existing Customer ID");
        update10.setFocusTraversable(false);
        TextField update11 = new TextField();
        update11.setPromptText("Input First Name");
        update11.setFocusTraversable(false); 
        TextField update12 = new TextField();
        TextField update13 = new TextField();
        update13.setPromptText("Input Last Name");
        update13.setFocusTraversable(false); 
        TextField update14 = new TextField();
        update14.setPromptText("Input Email Address");
        update14.setFocusTraversable(false); 
        TextField update15 = new TextField();
        update15.setPromptText("Input Phone Number");
        update15.setFocusTraversable(false); 
        TextField update16 = new TextField();
        update16.setPromptText("Input Bookings");
        update16.setFocusTraversable(false); 
        Label date8 = new Label();
        date8.setText("Input Date Last Visited : ");
        date8.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Update A Customer Date Pickers
        DatePicker datepick8 = new DatePicker();
        //Set Min AND/OR Max Dates
        final Callback<DatePicker, DateCell> dayCellFactory3;
        DatePicker maxDate3 = new DatePicker();
        maxDate3.setValue(LocalDate.now());
        dayCellFactory3 = (final DatePicker datePicker) -> new DateCell() {
        @Override
        public void updateItem(LocalDate item, boolean empty) {
        super.updateItem(item, empty);
        if (item.isBefore(maxDate3.getValue())) { //Disable all dates after required date
            setDisable(true);
            setStyle("-fx-background-color: #ffc0cb;"); //To set background on different color
        }
        }
        };
        //Finally, we just need to update our DatePicker cell factory as follow:
        datepick8.setDayCellFactory(dayCellFactory3);
        //Actions for Date To String Conversions
        datepick8.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                 LocalDate i8 = datepick8.getValue();
           update12.setText(i8.toString());
            }
        });
        //Update A Customer Combo-Boxes
        String form8 [] = {"CASH", "M-PESA", "CARD"};
        ComboBox form9 = new ComboBox(FXCollections.observableArrayList(form8));
        Label selected8 = new Label();
        selected8.setText("Select A Preffered Payment Type : ");
        selected8.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected9 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event4 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            selected9.setText((String) form9.getValue());
            }
        };
        form9.setOnAction(event4);
        String form10 [] = {"Male", "Female"};
        ComboBox form11 = new ComboBox(FXCollections.observableArrayList(form10));
        Label selected10 = new Label();
        selected10.setText("Select A Gender : ");
        selected10.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected11 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event5 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event5) {
            selected11.setText((String) form11.getValue());
            }
        };
        form11.setOnAction(event5);
        //Update A Customer Buttons
        Button backbtn9 = new Button();
        backbtn9.setText("Return");
        backbtn9.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn9.setTextFill(Color.RED);
        backbtn9.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene7);
            primaryStage.show();         
            }
        });
        Button updatebtn1 = new Button();
        updatebtn1.setText("Update");
        updatebtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        updatebtn1.setTextFill(Color.GREEN);
        //Action to Update A Customer 
        updatebtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                
                String cid = update10.getText();
                String cfname = update11.getText();
                String clname = update13.getText();
                String cemail = update14.getText();
                String cphone = update15.getText();
                String clastvisited = update12.getText();
                String cbookings = update16.getText();
                String cpayments = selected9.getText();
                String cgender = selected11.getText();
                
       a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Update This Customer ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(update10.getText().trim().isEmpty() || update11.getText().trim().isEmpty() || update12.getText().trim().isEmpty() || update13.getText().trim().isEmpty() || update14.getText().trim().isEmpty() || update15.getText().trim().isEmpty() || update16.getText().trim().isEmpty() || selected9.getText().trim().isEmpty() || selected11.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That All Fields Are Not Empty.");
           a.show();
         }else if(!cemail.contains("@")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains @.");
            a.show();
        } else if(!cemail.contains(".com")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains .com.");
            a.show();
        }else{          
            DBOperations upd = new DBOperations();
            upd.updateOperation1(cid,cfname,clname,cemail,cphone,clastvisited,cbookings,cpayments,cgender);
            update10.clear();
            update11.clear();
            update12.clear();
            update13.clear();
            update14.clear();
            update15.clear();
            update16.clear();
            selected9.clear();
            selected11.clear();
            form11.setValue(null);
            form9.setValue(null);
            datepick8.setValue(null);
            primaryStage.setScene(scene1);
            primaryStage.show();
            }
         }else if (result.get() == ButtonType.NO){  
            }
            }
        });
        //Set Style
        cupdate.setStyle(cssLayout);
        //Get Children/Elements for Update Customer Page
        cupdate.getChildren().addAll(imageView11, kindly9, update10, update11, update13, date8, datepick8, update14, update15, update16, selected8, form9, selected10, form11, updatebtn1, backbtn9);
        //Action to Set Scene to Update Customer Page when Update Customer Button on Customer Page is Clicked
         btn10.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene10);
            primaryStage.show();
            }
        });
        
        //SELECT A Customer VBOX
        VBox cselect = new VBox(10);
        cselect.setAlignment(Pos.CENTER);
        //Select A Customer Scene
        Scene scene11 = new Scene(cselect, 900, 1000);
        //Select A Customer Page
        //Select A Customer Images
        InputStream stream12 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image12 = new Image(stream12);
        //Creating the image view
        ImageView imageView12 = new ImageView();
        //Setting image to the image view
        imageView12.setImage(image12);
        //Setting the image view parameters
        imageView12.setX(10);
        imageView12.setY(10);
        imageView12.setFitWidth(700);
        imageView12.setPreserveRatio(true);
        //Select A Customer HCI Text
        Label kindly10 = new Label();
        kindly10.setText("Kindly fill in the field below to select a customer : ");
        kindly10.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Select A Customer TextField
        TextField select2 = new TextField();
        select2.setPromptText("Input Existing Customer ID");
        select2.setFocusTraversable(false);
        //Select A Customer Labels
        Label selection11 = new Label();
        selection11.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection12 = new Label();
        selection12.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection13 = new Label();
        selection13.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection14 = new Label();
        selection14.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection15 = new Label();
        selection15.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection16 = new Label();
        selection16.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection17 = new Label();
        selection17.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection18 = new Label();
        selection18.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection19 = new Label();
        selection19.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Select A Customer Buttons
        Button backbtn10 = new Button();
        backbtn10.setText("Return");
        backbtn10.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn10.setTextFill(Color.RED);
        backbtn10.setOnAction(new EventHandler<ActionEvent>() {

           @Override
           public void handle(ActionEvent event) {
           selection11.setText("");
           selection12.setText("");
           selection13.setText("");
           selection14.setText("");
           selection15.setText("");
           selection16.setText("");
           selection17.setText("");
           selection18.setText("");
           selection19.setText("");
           select2.clear();
           primaryStage.setScene(scene7);
           primaryStage.show();         
           }
        });
        Button selectbtn1 = new Button();
        selectbtn1.setText("Select");
        selectbtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        selectbtn1.setTextFill(Color.GREEN);
        //Action to Select A Customer 
        selectbtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             
                String cid = select2.getText();
            a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Select This Customer ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(select2.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That Customer ID is Not Empty.");
           a.show();
         }else{     
           DBOperations sel = new DBOperations();
           sel.selectOperation1(cid);
           selection11.setText("Customer ID : "+sel.cid1);
           selection12.setText("First Name : "+sel.cfname);
           selection13.setText("Last Name : "+sel.clname);
           selection14.setText("Email Address : "+sel.cemail);
           selection15.setText("Phone Number : "+sel.cphone);
           selection16.setText("Date Last Visited : "+sel.clastvisited);
           selection17.setText("Preffered Payment Type : "+sel.cpayments);
           selection18.setText("Bookings : "+sel.cbookings);
           selection19.setText("Gender : "+sel.cgender);
           }
        }else if (result.get() == ButtonType.NO){  
            }
         }
        });
        //Set Style
        cselect.setStyle(cssLayout);
        cselect.getChildren().addAll(imageView12, kindly10, select2, selectbtn1, backbtn10, selection11, selection12, selection13, selection14, selection15, selection16, selection17, selection18, selection19);

        btn11.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene11);
            primaryStage.show();
            }
        });
      
        
        //View Customers VBOX
        VBox vcustomer = new VBox(20);
        vcustomer.setAlignment(Pos.CENTER);
        //View Customers Scene
        Scene scene18 = new Scene(vcustomer, 900, 1000);
        //TableView for Customers
        TableView table1 = new TableView();
        //View Customers Button
        Button backbtn17 = new Button();
        backbtn17.setText("Return");
        backbtn17.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn17.setTextFill(Color.RED);
        backbtn17.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            table1.getItems().clear();
            primaryStage.setScene(scene7);
            primaryStage.show();         
            }
        });
        //View Customers Images
        InputStream stream13 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image13 = new Image(stream13);
        //Creating the image view
        ImageView imageView13 = new ImageView();
        //Setting image to the image view
        imageView13.setImage(image13);
        //Setting the image view parameters
        imageView13.setX(10);
        imageView13.setY(10);
        imageView13.setFitWidth(700);
        imageView13.setPreserveRatio(true);
        //View Customers HCI Text
        Label kindly17 = new Label();
        kindly17.setText("Below are the customers within our system: ");
        kindly17.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        
        table1.setStyle(tablelayout);
        vcustomer.setStyle(cssLayout);
        
         ObservableList<ObservableList> data1;
         Connection c1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/cinema_management_system","root","");
         data1 = FXCollections.observableArrayList();              
      
      vcustomer.getChildren().addAll(imageView13, kindly17, table1, backbtn17);
      viewbtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            try{
            Class.forName("com.mysql.jdbc.Driver");
            //SQL FOR SELECTING ALL OF CUSTOMERS
            String SQL1 = "SELECT * FROM customers";
            //ResultSet
            ResultSet rs1 = c1.createStatement().executeQuery(SQL1);
            //TABLE COLUMN ADDED DYNAMICALLY 
            for(int i=0 ; i<rs1.getMetaData().getColumnCount(); i++){
                //We are using non property style for making dynamic table
                final int j = i;                
                TableColumn col1 = new TableColumn(rs1.getMetaData().getColumnName(i+1));
                col1.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
                        return new SimpleStringProperty(param.getValue().get(j).toString());                        
                    }                    
                });

                table1.getColumns().addAll(col1); 
                //System.out.println("Column ["+i+"] ");
            }
            //Data added to ObservableList *
            while(rs1.next()){
                //Iterate Row
                ObservableList<String> row1 = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs1.getMetaData().getColumnCount(); i++){
                    //Iterate Column
                    row1.add(rs1.getString(i));
                }
                //System.out.println("Row [1] added "+row );
                data1.add(row1);
                
            }

            //FINALLY ADDED TO TableView
            table1.setItems(data1);
          }catch(Exception e){
              e.printStackTrace();
              System.out.println("Error on Building Data");             
          }
            primaryStage.setScene(scene18);
            primaryStage.show();         
            }
        });
        
        //STAFF SECTION
        //Staff VBOX
        VBox staff = new VBox(20);
        staff.setAlignment(Pos.CENTER);
        //Staff Scene
        Scene scene12 = new Scene(staff, 900, 800);
        //Staff Page
        //Staff Images
        InputStream stream14 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image14 = new Image(stream14);
        //Creating the image view
        ImageView imageView14 = new ImageView();
        //Setting image to the image view
        imageView14.setImage(image14);
        //Setting the image view parameters
        imageView14.setX(10);
        imageView14.setY(10);
        imageView14.setFitWidth(700);
        imageView14.setPreserveRatio(true);
        //Staff HCI Text
        Label kindly11 = new Label();
        kindly11.setText("Kindly select an option to proceed : ");
        kindly11.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Staff Buttons
        Button btn12 = new Button();
        btn12.setText("Insert A New Staff");
        btn12.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn12.setTextFill(Color.BLUE);
        Button btn13 = new Button();
        btn13.setText("Delete A Staff");
        btn13.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn13.setTextFill(Color.BLUE);
        Button btn14 = new Button();
        btn14.setText("Update A Staff");
        btn14.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn14.setTextFill(Color.BLUE);
        Button btn15 = new Button();
        btn15.setText("Select A Staff");
        btn15.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        btn15.setTextFill(Color.BLUE);
        Button viewbtn3 = new Button();
        viewbtn3.setText("View Staff");
        viewbtn3.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        viewbtn3.setTextFill(Color.BLUE);
        Button backbtn11 = new Button();
        backbtn11.setText("Return");
        backbtn11.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn11.setTextFill(Color.RED);
        //Action to Set Scene to Homepage when Return Button on Staff Page is Clicked
        backbtn11.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene1);
            primaryStage.show();         
            }
        });
        //Set Style
        staff.setStyle(cssLayout);
        //Get Children/Elements for Staff Page
        staff.getChildren().addAll(imageView14, kindly11, btn12, btn13, btn14, btn15, viewbtn3, backbtn11);
        //Action to Set Scene to Staff Page when Staff Button on Homepage is Clicked
         btn3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene12);
            primaryStage.show();
            }
        });
        
        //Insert A Staff VBOX
        VBox sinsert = new VBox(10);
        sinsert.setAlignment(Pos.CENTER);
        //Insert A Staff Scene
        Scene scene13 = new Scene(sinsert, 900, 1000);
        //Insert A Staff Page
        //Insert A Staff Images
        InputStream stream15 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image15 = new Image(stream15);
        //Creating the image view
        ImageView imageView15 = new ImageView();
        //Setting image to the image view
        imageView15.setImage(image15);
        //Setting the image view parameters
        imageView15.setX(10);
        imageView15.setY(10);
        imageView15.setFitWidth(700);
        imageView15.setPreserveRatio(true);
        //Insert A Staff HCI Text
        Label kindly12 = new Label();
        kindly12.setText("Kindly fill the fields below to insert a Staff : ");
        kindly12.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Insert A Staff TimeSpinners from the TimeSpinner Class
        TextField insert16 = new TextField();
        TextField insert17 = new TextField();
        insert17.setVisible(false);
        insert16.setVisible(false);
        Label start = new Label();
        start.setText("Start Shift : ");
        start.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label end = new Label();
        end.setText("End Shift : ");
        end.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TimeSpinner spinner = new TimeSpinner();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss");
        spinner.valueProperty().addListener((obs, oldTime, newTime) ->
        insert16.setText(formatter.format(newTime)));
        TimeSpinner spinner1 = new TimeSpinner();
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("hh:mm:ss");
        spinner1.valueProperty().addListener((obs, oldTime, newTime) ->
        insert17.setText(formatter1.format(newTime)));
        //Insert A Staff TextFields
        TextField insert15 = new TextField();
        insert15.setPromptText("Input First Name");
        insert15.setFocusTraversable(false); 
        TextField insert18 = new TextField();
        insert18.setPromptText("Input Last Name");
        insert18.setFocusTraversable(false); 
        TextField insert19 = new TextField();
        insert19.setPromptText("Input Email Address");
        insert19.setFocusTraversable(false); 
        TextField insert20 = new TextField();
        insert20.setPromptText("Input Phone Number");
        insert20.setFocusTraversable(false); 
        TextField insert21 = new TextField();
        insert21.setPromptText("Input Salary");
        insert21.setFocusTraversable(false); 
        //Insert A Staff Combo-Boxes
        String form12 [] = {"Manager", "Cashier", "Attendant", "Technichain"};
        ComboBox form13 = new ComboBox(FXCollections.observableArrayList(form12));
        Label selected12 = new Label();
        selected12.setText("Select A Job Type : ");
        selected12.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected13 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event6 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event6) {
            selected13.setText((String) form13.getValue());
            }
        };
        form13.setOnAction(event6);
        //Insert A Staff Combo-Boxes
        String form14 [] = {"Male", "Female"};
        ComboBox form15 = new ComboBox(FXCollections.observableArrayList(form14));
        Label selected14 = new Label();
        selected14.setText("Select A Gender : ");
        selected14.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected15 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event7 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event7) {
            selected15.setText((String) form15.getValue());
            }
        };
        form15.setOnAction(event7);
        //Insert A Staff Buttons
        Button backbtn12 = new Button();
        backbtn12.setText("Return");
        backbtn12.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn12.setTextFill(Color.RED);
        backbtn12.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene12);
            primaryStage.show();         
            }
        });
        Button insertbtn2 = new Button();
        insertbtn2.setText("Insert");
        insertbtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        insertbtn2.setTextFill(Color.GREEN);
        //Action to Insert Data Into The Database
        insertbtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
        //Get String Values from required TextFields and Labels
                String sfname = insert15.getText();
                String slname = insert18.getText();
                String sjobtype = selected13.getText();
                String ssalary = insert21.getText();
                String semail = insert19.getText();
                String sphone = insert20.getText();
                String sgender = selected15.getText();
                String sstartshift = insert16.getText();
                String sendshift = insert17.getText();
                
            a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Insert A Staff ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(insert15.getText().trim().isEmpty() || insert16.getText().trim().isEmpty() || insert17.getText().trim().isEmpty() || insert18.getText().trim().isEmpty() || insert19.getText().trim().isEmpty() || insert20.getText().trim().isEmpty() || insert21.getText().trim().isEmpty() || selected15.getText().trim().isEmpty() || selected13.getText().trim().isEmpty()){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Kindly Ensure That All Fields Are Not Empty.");
            a.show();
         }else if(!semail.contains("@")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains @.");
            a.show();
        } else if(!semail.contains(".com")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains .com.");
            a.show();
        }else{
             DBOperations inc = new DBOperations();
             inc.insertOperation2(sfname,slname,sjobtype,ssalary,semail,sphone,sgender,sstartshift,sendshift);
             insert15.clear();
             insert16.setText("");
             insert17.setText("");
             insert18.clear();
             insert19.clear();
             insert20.clear();
             insert21.clear();
             selected13.clear();
             selected15.clear();
             form13.setValue(null);
             form15.setValue(null);
             primaryStage.setScene(scene1);
             primaryStage.show();
         }
          }else if (result.get() == ButtonType.NO){  
            }
            }
        });
        //Set Style
        sinsert.setStyle(cssLayout);
        //Get Children/Elements for Insert Staff Page
        sinsert.getChildren().addAll(imageView15, kindly12, insert15, insert18, insert19, insert20, insert21, start, spinner, end, spinner1, selected12, form13, selected14, form15, insertbtn2, backbtn12, insert16, insert17);
        //Action to Set Scene to Insert Staff Page when Insert Staff Button on Staff Page is Clicked
        btn12.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene13);
            primaryStage.show();
            }
        });
        
        //Delete A Staff VBOX
        VBox sdelete = new VBox(15);
        sdelete.setAlignment(Pos.CENTER);
        //Delete A Staff Scene
        Scene scene14 = new Scene(sdelete, 900, 800);
        //Delete A Staff Page
        //Delete A Staff Title
        InputStream stream16 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image16 = new Image(stream16);
        //Creating the image view
        ImageView imageView16 = new ImageView();
        //Setting image to the image view
        imageView16.setImage(image16);
        //Setting the image view parameters
        imageView16.setX(10);
        imageView16.setY(10);
        imageView16.setFitWidth(700);
        imageView16.setPreserveRatio(true);
        //Delete A Staff HCI Text
        Label kindly13 = new Label();
        kindly13.setText("Kindly fill the field below to delete a staff : ");
        kindly13.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Delete A Staff TextFields
        TextField delete3 = new TextField();
        delete3.setPromptText("Input Staff ID");
        delete3.setFocusTraversable(false); 
        //Delete A Staff Buttons
        Button backbtn13 = new Button();
        backbtn13.setText("Return");
        backbtn13.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn13.setTextFill(Color.RED);
        backbtn13.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene12);
            primaryStage.show();         
            }
        });
        Button deletebtn2 = new Button();
        deletebtn2.setText("Delete");
        deletebtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        deletebtn2.setTextFill(Color.GREEN);
        //Action to Delete Data From the Database
        deletebtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             
               String sid = delete3.getText();
                 a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Delete A Staff ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(delete3.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That The Staff ID Is Not Empty.");
           a.show();
         }else{
            DBOperations del = new DBOperations() {};
            del.deleteOperation2(sid);
            delete3.clear();
            primaryStage.setScene(scene1);
            primaryStage.show();
            }
        }else if (result.get() == ButtonType.NO){  
            }    
            }
        });
        //Set Style
        sdelete.setStyle(cssLayout);
        //Get Children/Elements for Delete Staff Page
        sdelete.getChildren().addAll(imageView16, kindly13, delete3, deletebtn2, backbtn13);
        //Action to Set Scene to Delete Staff Page when Delete Staff Button on Staff Page is Clicked
        btn13.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene14);
            primaryStage.show();
            }
        });
        
        //UPDATE A Staff VBOX
        VBox supdate = new VBox(10);
        supdate.setAlignment(Pos.CENTER);
        //Update A Staff Scene
        Scene scene15 = new Scene(supdate, 900, 1000);    
        //Update A Staff Page
        //Update A Staff Images
        InputStream stream17 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image17 = new Image(stream17);
        //Creating the image view
        ImageView imageView17 = new ImageView();
        //Setting image to the image view
        imageView17.setImage(image17);
        //Setting the image view parameters
        imageView17.setX(10);
        imageView17.setY(10);
        imageView17.setFitWidth(700);
        imageView17.setPreserveRatio(true);
        //Update A Staff HCI Text
        Label kindly14 = new Label();
        kindly14.setText("Kindly fill the fields below to update a Staff : ");
        kindly14.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Update A Staff TimeSpinners from the TimeSpinner Class
        TextField update18 = new TextField();
        TextField update19 = new TextField();
        Label start1 = new Label();
        start1.setText("Start Shift : ");
        start1.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label end1 = new Label();
        end1.setText("End Shift : ");
        end1.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TimeSpinner spinner2 = new TimeSpinner();
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("hh:mm:ss");
        spinner2.valueProperty().addListener((obs, oldTime, newTime) ->
        update18.setText(formatter2.format(newTime)));
        TimeSpinner spinner3 = new TimeSpinner();
        DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("hh:mm:ss");
        spinner3.valueProperty().addListener((obs, oldTime, newTime) ->
        update19.setText(formatter3.format(newTime)));
        //Update A Staff TextFields
        TextField update24 = new TextField();
        update24.setPromptText("Input Existing Staff ID");
        update24.setFocusTraversable(false); 
        TextField update17 = new TextField();
        update17.setPromptText("Input First Name");
        update17.setFocusTraversable(false); 
        TextField update20 = new TextField();
        update20.setPromptText("Input Last Name");
        update20.setFocusTraversable(false); 
        TextField update21 = new TextField();
        update21.setPromptText("Input Email Address");
        update21.setFocusTraversable(false); 
        TextField update22 = new TextField();
        update22.setPromptText("Input Phone Number");
        update22.setFocusTraversable(false); 
        TextField update23 = new TextField();
        update23.setPromptText("Input Salary");
        update23.setFocusTraversable(false); 
        //Update A Staff Combo-Boxes
        String form16 [] = {"Manager", "Cashier", "Technichian"};
        ComboBox form17 = new ComboBox(FXCollections.observableArrayList(form16));
        Label selected16 = new Label();
        selected16.setText("Select A Job Type : ");
        selected16.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected17 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event8 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event8) {
            selected17.setText((String) form17.getValue());
            }
        };
        form17.setOnAction(event8);
        //Update A Staff Combo-Boxes
        String form18 [] = {"Male", "Female"};
        ComboBox form19 = new ComboBox(FXCollections.observableArrayList(form18));
        Label selected18 = new Label();
        selected18.setText("Select A Gender : ");
        selected18.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        TextField selected19 = new TextField();
        //Action to Set Data to a String Label once Combo-Box is selected
        EventHandler<ActionEvent> event9 = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event9) {
            selected19.setText((String) form19.getValue());
            }
        };
        form19.setOnAction(event9);
        //Update A Staff Buttons
        Button backbtn14 = new Button();
        backbtn14.setText("Return");
        backbtn14.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn14.setTextFill(Color.RED);
        backbtn14.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene12);
            primaryStage.show();         
            }
        });
        Button updatebtn2 = new Button();
        updatebtn2.setText("Update");
        updatebtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        updatebtn2.setTextFill(Color.GREEN);
        //Action to Update A Staff 
        updatebtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                
                //Get String Values from required TextFields
                String sid = update24.getText();
                String sfname = update17.getText();
                String slname = update20.getText();
                String sjobtype = selected17.getText();
                String ssalary = update23.getText();
                String semail = update21.getText();
                String sphone = update22.getText();
                String sgender = selected19.getText();
                String sstartshift = update18.getText();
                String sendshift = update19.getText();
                
            a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Update A Staff ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(update17.getText().trim().isEmpty() || update18.getText().trim().isEmpty() || update19.getText().trim().isEmpty() || update20.getText().trim().isEmpty() || update21.getText().trim().isEmpty() || update22.getText().trim().isEmpty() || update23.getText().trim().isEmpty() || update24.getText().trim().isEmpty() || selected17.getText().trim().isEmpty() || selected19.getText().trim().isEmpty()){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Kindly Ensure That All Fields Are Not Empty.");
            a.show();
         }else if(!semail.contains("@")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains @.");
            a.show();
        } else if(!semail.contains(".com")){
            a.setAlertType(AlertType.WARNING);
            a.setContentText("Ensure Email Address contains .com.");
            a.show();
        }else{
             DBOperations upd = new DBOperations();
             upd.updateOperation2(sid,sfname,slname,sjobtype,ssalary,semail,sphone,sgender,sstartshift,sendshift);
             update17.clear();
             update18.clear();
             update19.clear();
             update20.clear();
             update21.clear();
             update22.clear();
             update23.clear();
             update24.clear();
             selected17.clear();
             selected19.clear();
             form17.setValue(null);
             form19.setValue(null);
             primaryStage.setScene(scene1);
             primaryStage.show();
         }
          }else if (result.get() == ButtonType.NO){  
            }
            }
        });
        //Set Style
        supdate.setStyle(cssLayout);
        //Get Children/Elements for Update Staff Page
        supdate.getChildren().addAll(imageView17, kindly14, update24, update17, update20, update21, update22, update23, start1, spinner2, end1, spinner3, selected16, form17, selected18, form19, updatebtn2, backbtn14);
        //Action to Set Scene to Update Staff Page when Update Staff Button on Staff Page is Clicked
         btn14.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene15);
            primaryStage.show();
            }
        });
        
        //SELECT A Staff VBOX
        VBox sselect = new VBox(10);
        sselect.setAlignment(Pos.CENTER);
        //Select A Staff Scene
        Scene scene16 = new Scene(sselect, 900, 1000);
        //Select A Staff Page
        //Select A Staff Images
        InputStream stream18 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image18 = new Image(stream18);
        //Creating the image view
        ImageView imageView18 = new ImageView();
        //Setting image to the image view
        imageView18.setImage(image18);
        //Setting the image view parameters
        imageView18.setX(10);
        imageView18.setY(10);
        imageView18.setFitWidth(700);
        imageView18.setPreserveRatio(true);
        //Select A Staff HCI Text
        Label kindly15 = new Label();
        kindly15.setText("Kindly fill in the field below to select a staff : ");
        kindly15.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Select A Staff TextField
        TextField select3 = new TextField();
        select3.setPromptText("Input Existing Staff ID");
        select3.setFocusTraversable(false);
        //Select A Staff Labels
        Label selection20 = new Label();
        selection20.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection21 = new Label();
        selection21.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection22 = new Label();
        selection22.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection23 = new Label();
        selection23.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection24 = new Label();
        selection24.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection25 = new Label();
        selection25.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection26 = new Label();
        selection26.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection27 = new Label();
        selection27.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        Label selection28 = new Label();
        selection28.setFont(Font.font("Comic Sans MS", FontWeight.THIN, FontPosture.ITALIC, 25));
        //Select A Staff Buttons
        Button backbtn15 = new Button();
        backbtn15.setText("Return");
        backbtn15.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn15.setTextFill(Color.RED);
        backbtn15.setOnAction(new EventHandler<ActionEvent>() {

           @Override
           public void handle(ActionEvent event) {
           selection20.setText("");
           selection21.setText("");
           selection22.setText("");
           selection23.setText("");
           selection24.setText("");
           selection25.setText("");
           selection26.setText("");
           selection27.setText("");
           selection28.setText("");
           select3.clear();
           primaryStage.setScene(scene12);
           primaryStage.show();         
           }
        });
        Button selectbtn2 = new Button();
        selectbtn2.setText("Select");
        selectbtn2.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        selectbtn2.setTextFill(Color.GREEN);
        //Action to Select A Staff 
        selectbtn2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             
            String sid = select3.getText();
            a.setAlertType(AlertType.CONFIRMATION);
            a.setContentText("Are You Sure That You Want To Select This Staff ?");
                
        Optional<ButtonType> result = a.showAndWait();
         if(!result.isPresent()){  
         }else if(result.get() == ButtonType.OK){
         if(select3.getText().trim().isEmpty()){
           a.setAlertType(AlertType.WARNING);
           a.setContentText("Kindly Ensure That Staff ID is Not Empty.");
           a.show();
         }else{     
           DBOperations sel = new DBOperations();
           sel.selectOperation2(sid);
           selection20.setText("Staff ID : "+sel.sid1);
           selection21.setText("First Name : "+sel.sfname);
           selection22.setText("Last Name : "+sel.slname);
           selection23.setText("Email Address : "+sel.semail);
           selection24.setText("Phone Number : "+sel.sphone);
           selection25.setText("Job Type : "+sel.sjobtype);
           selection26.setText("Start Shift : "+sel.sstartshift);
           selection27.setText("End Shift : "+sel.sendshift);
           selection28.setText("Gender : "+sel.sgender);
           }
        }else if (result.get() == ButtonType.NO){  
            }
         }
        });
        //Set Style
        sselect.setStyle(cssLayout);
        sselect.getChildren().addAll(imageView18, kindly15, select3, selectbtn2, backbtn15, selection20, selection21, selection22, selection23, selection24, selection25, selection26, selection27, selection28);

        btn15.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene16);
            primaryStage.show();
            }
        });
      
        //View Staff VBOX
        VBox vstaff = new VBox(20);
        vstaff.setAlignment(Pos.CENTER);
        //View Staff Scene
        Scene scene19 = new Scene(vstaff, 800, 1000);
        //TableView for Staff
        TableView table2 = new TableView();
        //View Staff Button
        Button backbtn18 = new Button();
        backbtn18.setText("Return");
        backbtn18.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        backbtn18.setTextFill(Color.RED);
        backbtn18.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            table2.getItems().clear();
            primaryStage.setScene(scene12);
            primaryStage.show();         
            }
        });
        //View Staff Title
        InputStream stream19 = new FileInputStream("F:\\Pictures\\logo.png");
        Image image19 = new Image(stream19);
        //Creating the image view
        ImageView imageView19 = new ImageView();
        //Setting image to the image view
        imageView19.setImage(image19);
        //Setting the image view parameters
        imageView19.setX(10);
        imageView19.setY(10);
        imageView19.setFitWidth(700);
        imageView19.setPreserveRatio(true);
        //View Staff HCI Text
        Label kindly18 = new Label();
        kindly18.setText("Below are the staff within our system: ");
        kindly18.setFont(Font.font("Bell MT", FontWeight.THIN, FontPosture.ITALIC, 25));

        vstaff.setStyle(cssLayout);
        table2.setStyle(tablelayout);
        
         ObservableList<ObservableList> data2;
         Connection c2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/cinema_management_system","root","");
         data2 = FXCollections.observableArrayList();
      
      vstaff.getChildren().addAll(imageView19, kindly18, table2, backbtn18);
      viewbtn3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
             try{
            Class.forName("com.mysql.jdbc.Driver");
            //SQL FOR SELECTING ALL OF STAFF
            String SQL2 = "SELECT * FROM staff";
            //ResultSet
            ResultSet rs2 = c2.createStatement().executeQuery(SQL2);
            //TABLE COLUMN ADDED DYNAMICALLY 
            for(int i=0 ; i<rs2.getMetaData().getColumnCount(); i++){
                //We are using non property style for making dynamic table
                final int j = i;                
                TableColumn col2 = new TableColumn(rs2.getMetaData().getColumnName(i+1));
                col2.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
                        return new SimpleStringProperty(param.getValue().get(j).toString());                        
                    }                    
                });

                table2.getColumns().addAll(col2); 
                //System.out.println("Column ["+i+"] ");
            }
            //Data added to ObservableList *
            while(rs2.next()){
                //Iterate Row
                ObservableList<String> row2 = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs2.getMetaData().getColumnCount(); i++){
                    //Iterate Column
                    row2.add(rs2.getString(i));
                }
                //System.out.println("Row [1] added "+row );
                data2.add(row2);

            }

            //FINALLY ADDED TO TableView
            table2.setItems(data2);
          }catch(Exception e){
              e.printStackTrace();
              System.out.println("Error on Building Data");             
          }
            primaryStage.setScene(scene19);
            primaryStage.show();         
            }
        });
        
        //Are You Sure ? SECTION
        Label title = new Label();
        title.setText("Are You Sure You Want To Exit ?");
        title.setFont(Font.font("Chiller", FontWeight.BOLD, 50));
        title.setTextFill(Color.RED);
        InputStream stream2 = new FileInputStream("F:\\Pictures\\are.jpeg");
        Image image2 = new Image(stream2);
        //Creating the image view
        ImageView imageView2 = new ImageView();
        //Setting image to the image view
        imageView2.setImage(image2);
        //Setting the image view parameters
        imageView2.setX(10);
        imageView2.setY(10);
        imageView2.setFitWidth(320);
        imageView2.setPreserveRatio(true);
        Button byebtn1 = new Button();
        byebtn1.setText("Yes");
        byebtn1.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        byebtn1.setTextFill(Color.RED);
        Button nah = new Button();
        nah.setText("No");
        nah.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 30));
        nah.setTextFill(Color.GREEN);
        //CSS for Secondary Layout
        String cssLayout1 = "-fx-border-color: black;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 3;\n" +
                    "-fx-background-color : linear-gradient(white, red, black);"+
                   "-fx-border-style: solid;\n";
        //Exit VBOX
        VBox exit = new VBox(20);
        exit.setStyle(cssLayout1);
        exit.setAlignment(Pos.CENTER);
        //Exit Scene
        Scene scene20 = new Scene(exit, 900, 800);
        exit.getChildren().addAll(title, imageView2, byebtn1, nah);
        //Button To Exit The primaryStage
        byebtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            primaryStage.setScene(scene20);
            primaryStage.show();
            }
        });
        nah.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            a.setAlertType(AlertType.INFORMATION);
            a.setContentText("Nice, now watch another movie :)");
            a.showAndWait(); 
            primaryStage.setScene(scene1);
            primaryStage.show();
            }
        });
        byebtn1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
            a.setAlertType(AlertType.INFORMATION);
            a.setContentText("Thank you for using our system :)");
            a.showAndWait();    
            primaryStage.close();
            }
        });
        
    }

    public static void main(String[]args){
        launch(args);
    }
    
}
