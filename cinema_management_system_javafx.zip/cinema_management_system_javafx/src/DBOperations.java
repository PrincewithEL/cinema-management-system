import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.scene.control.Alert;

/**
 *
 * @author Asher (137187)
 */
public class DBOperations extends DBConnection {
    //Alert Pop-Up
    Alert a = new Alert(Alert.AlertType.NONE);
    //Strings for Movie Selections
    String mid1;
    String mname;
    String mdateadded;
    String mshowingstart;
    String mshowingend;
    String mstudio;
    String msupplier;
    String mformat;
    String mgenre;
    String mruntime;
    //Strings for Customer Selections
    String cid1;
    String cfname;
    String clname;
    String cemail;
    String cphone;
    String clastvisited;
    String cbookings;
    String cpayments;
    String cgender;
    //Strings for Staff Selections
    String sid1;
    String sfname;
    String slname;
    String sjobtype;
    String ssalary;
    String semail;
    String sphone;
    String sgender;
    String sstartshift;
    String sendshift;

    @Override
    public void insertOperation(String name, String date_added, String show_start, String show_end, String studio, String supplier, String form, String gen, String run) {
        try{
     
       String query1 = "INSERT INTO `movies`(`Name`, `Date_Added`, `Showing_Start`, `Showing_End`, `Movie_Studio`, `Movie_Suppliers`, `Format`, `Genre`, `Runtime`) VALUES ('"+name+"','"+date_added+"','"+show_start+"','"+show_end+"','"+studio+"','"+supplier+"','"+form+"','"+gen+"','"+run+" min')";
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1==1){
           a.setAlertType(Alert.AlertType.INFORMATION);
           a.setContentText("New Movie " + name + " has been inserted into the database.");
           a.showAndWait();
           System.out.println("The Movie Details for : "+name+" have been successfully added into the database.");
       }else{
            System.out.println("Could not insert the Movie Details into the Database kindly try again.");
       }
       
       con.close();
              
        }catch(SQLException sqle){
        System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
    }
    }

    @Override
    public void selectOperation(String mid) {
        try{
       String query = "SELECT * FROM `movies` WHERE `Movie_ID` = "+mid;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){
             mid1 = rs.getString(1);
             mname = rs.getString(2);
             mdateadded = rs.getString(3);
             mshowingstart = rs.getString(4);
             mshowingend = rs.getString(5);
             mstudio = rs.getString(6);
             msupplier = rs.getString(7);
             mformat = rs.getString(8);
             mgenre = rs.getString(9);
             mruntime = rs.getString(10);
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Search for Movie ID "+mid+" is successful!");
            a.show();
            System.out.println("The Movie Details queried for are : "+mid1+"\t"+mname+"\t"+mdateadded+"\t"+mshowingstart+"\t"+mshowingend+"\t"+mstudio+"\t"+msupplier+"\t"+mformat+"\t"+mgenre+"\t"+mruntime);
       }else{
        a.setAlertType(Alert.AlertType.ERROR);
        a.setContentText("Movie ID " + mid + " does not exist kindly try again with an existing Movie ID.");
        a.showAndWait();
       }
       
       con.close();
       
        }catch(SQLException sqle){
        System.out.println("Movie Details not found, the following error occured: "+sqle.getMessage());
    }
    }
    @Override
    public void deleteOperation(String mid) {
        try{
       String query = "SELECT * FROM `movies` WHERE `Movie_ID` = "+mid;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){ 
       String query1 = "DELETE FROM `movies` WHERE `Movie_ID` = "+mid;
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1 == 1){
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Existing Movie ID " + mid + " has been deleted from the database.");
            a.showAndWait();
           System.out.println("The Movie Details for Movie ID : "+mid+" have been successfully delete from the database.");
       }else{
            System.out.println("Could not delete the Movie Details from the Database kindly try again.");
       }
       }else{
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Movie ID " + mid + " does not exist kindly try again with an existing Movie ID.");
            a.showAndWait();
            System.out.println("Could not find the Movie Details from the Database kindly try again with a different Movie ID.");
       }
       con.close();
       
        }catch(SQLException sqle){
        System.out.println("Movie Details not found, the following error occured: "+sqle.getMessage());
    }
    }

    @Override
    public void updateOperation(String mid1, String name, String date_added, String show_start, String show_end, String studio, String supplier, String form, String gen, String run) {
      try{
          
       String query = "SELECT * FROM `movies` WHERE `Movie_ID` = "+mid1;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){   
       String query1 = "UPDATE `movies` SET `Name`='"+name+"',`Date_Added`='"+date_added+"',`Showing_Start`='"+show_start+"',`Showing_End`='"+show_end+"',`Movie_Studio`='"+studio+"',`Movie_Suppliers`='"+supplier+"',`Format`='"+form+"',`Genre`='"+gen+"',`Runtime`='"+run+" min' WHERE `Movie_ID`='"+mid1+"'";
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1 == 1){
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Existing Movie ID " + mid1 + " has been updated in the database.");
            a.showAndWait();
           System.out.println("The Movie Details for Movie ID : "+mid1+" have been successfully updated on the database.");
       }else{
            System.out.println("Could not delete the Movie Details from the Database kindly try again.");
       }
       
       con.close();
       
        }else{
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Movie ID " + mid1 + " does not exist kindly try again with an existing Movie ID.");
            a.showAndWait();
            System.out.println("Could not find the Movie Details from the Database kindly try again with a different Movie ID.");
       }
      }catch(SQLException sqle){
        System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
    } 
    }

    @Override
    public void insertOperation1(String cfname, String clname, String cemail, String cphone, String clastvisited, String cbookings, String cpayment, String cgender) {
    try{
     
       String query1 = "INSERT INTO `customers`(`First_Name`, `Last_Name`, `Email_Address`, `Phone_Number`, `Last_Visited`, `Bookings`, `prefferedPayment_Type`, `Gender`) VALUES ('"+cfname+"','"+clname+"','"+cemail+"','"+cphone+"','"+clastvisited+"','"+cbookings+"','"+cpayment+"','"+cgender+"')";
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1==1){
           a.setAlertType(Alert.AlertType.INFORMATION);
           a.setContentText("New Customer " + cfname + " " + clname + " has been inserted into the database.");
           a.showAndWait();
           System.out.println("The Customer Details for : " + cfname + " " + clname + " have been successfully added into the database.");
       }else{
            System.out.println("Could not insert the Customer Details into the Database kindly try again.");
       }
       
       con.close();
              
        }catch(SQLException sqle){
        System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
    }    
    }

    @Override
    public void selectOperation1(String cid) {
     try{
       String query = "SELECT * FROM `customers` WHERE `Customer_ID` = "+cid;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){
            cid1 = rs.getString(1);
            cfname = rs.getString(2);
            clname = rs.getString(3);
            cemail = rs.getString(4);
            cphone = rs.getString(5);
            clastvisited = rs.getString(6);
            cbookings = rs.getString(7);
            cpayments = rs.getString(8);
            cgender = rs.getString(9);
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Search for Customer ID "+cid+" is successful!");
            a.show();
            System.out.println("The Movie Details queried for are : "+cid1+"\t"+cfname+"\t"+clname+"\t"+cemail+"\t"+cphone+"\t"+clastvisited+"\t"+cbookings+"\t"+cpayments+"\t"+cgender);
       }else{
        a.setAlertType(Alert.AlertType.ERROR);
        a.setContentText("Customer ID " + cid + " does not exist kindly try again with an existing Customer ID.");
        a.showAndWait();
       }
       
       con.close();
       
        }catch(SQLException sqle){
        System.out.println("Customer Details not found, the following error occured: "+sqle.getMessage());
    }    
    }

    @Override
    public void deleteOperation1(String cid) {
     try{
       String query = "SELECT * FROM `customers` WHERE `Customer_ID` = "+cid;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){ 
       String query1 = "DELETE FROM `customers` WHERE `Customer_ID` = "+cid;
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1 == 1){
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Existing Customer ID " + cid + " has been deleted from the database.");
            a.showAndWait();
           System.out.println("The Customer Details for Customer ID : "+cid+" have been successfully delete from the database.");
       }else{
            System.out.println("Could not delete the Customer Details from the Database kindly try again.");
       }
       }else{
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Customer ID " + cid + " does not exist kindly try again with an existing Customer ID.");
            a.showAndWait();
            System.out.println("Could not find the Customer Details from the Database kindly try again with a different Customer ID.");
       }
       con.close();
       
        }catch(SQLException sqle){
        System.out.println("Customer Details not found, the following error occured: "+sqle.getMessage());
    }    
    }

    @Override
    public void updateOperation1(String cid1, String cfname, String clname, String cemail, String cphone, String clastvisited, String cbookings, String cpayments, String cgender) {
    try{
          
       String query = "SELECT * FROM `customers` WHERE `Customer_ID` = "+cid1;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){   
       String query1 = "UPDATE `customers` SET `First_Name`='"+cfname+"',`Last_Name`='"+clname+"',`Email_Address`='"+cemail+"',`Phone_Number`='"+cphone+"',`Last_Visited`='"+clastvisited+"',`Bookings`='"+cbookings+"',`prefferedPayment_Type`='"+cpayments+"',`Gender`='"+cgender+"' WHERE `Customer_ID`='"+cid1+"'";
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1 == 1){
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Existing Customer ID " + cid1 + " has been updated in the database.");
            a.showAndWait();
           System.out.println("The Customer Details for Customer ID : "+cid1+" have been successfully updated on the database.");
       }else{
            System.out.println("Could not delete the Customer Details from the Database kindly try again.");
       }
       
       con.close();
       
        }else{
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Customer ID " + cid1 + " does not exist kindly try again with an existing Customer ID.");
            a.showAndWait();
            System.out.println("Could not find the Customer Details from the Database kindly try again with a different Customer ID.");
       }
      }catch(SQLException sqle){
        System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
    }     
    }

    @Override
    public void insertOperation2(String sfname, String slname, String sjobtype, String ssalary, String semail, String sphone, String sgender, String sstartshift, String sendshift) {
    try{
     
       String query1 = "INSERT INTO `staff`(`First_Name`, `Last_Name`, `Job_Type`, `Salary`, `Email_Address`, `Phone_Number`, `Gender`, `Start_Shift`, `End_Shift`) VALUES ('"+sfname+"','"+slname+"','"+sjobtype+"','"+ssalary+"','"+semail+"','"+sphone+"','"+sgender+"','"+sstartshift+"','"+sendshift+"')";
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1==1){
           a.setAlertType(Alert.AlertType.INFORMATION);
           a.setContentText("New Staff " + sfname + " " + slname + " has been inserted into the database.");
           a.showAndWait();
           System.out.println("The Staff Details for : " + sfname + " " + slname + " have been successfully added into the database.");
       }else{
            System.out.println("Could not insert the Staff Details into the Database kindly try again.");
       }
       
       con.close();
              
        }catch(SQLException sqle){
        System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
    }   
    }

    @Override
    public void selectOperation2(String sid) {
       try{
       String query = "SELECT * FROM `staff` WHERE `Staff_ID` = "+sid;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){
             sid1 = rs.getString(1);
             sfname = rs.getString(2);
             slname = rs.getString(3);
             sjobtype = rs.getString(4);
             ssalary = rs.getString(5);
             semail = rs.getString(6);
             sphone = rs.getString(7);
             sgender = rs.getString(8);
             sstartshift = rs.getString(9);
             sendshift = rs.getString(10);
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Search for Staff ID "+sid+" is successful!");
            a.show();
            System.out.println("The Staff Details queried for are : "+sid1+"\t"+sfname+"\t"+slname+"\t"+sjobtype+"\t"+ssalary+"\t"+semail+"\t"+sphone+"\t"+sgender+"\t"+sstartshift+"\t"+sendshift);
       }else{
        a.setAlertType(Alert.AlertType.ERROR);
        a.setContentText("Staff ID " + sid + " does not exist kindly try again with an Existing Staff ID.");
        a.showAndWait();
       }
       
       con.close();
       
        }catch(SQLException sqle){
        System.out.println("Staff Details not found, the following error occured: "+sqle.getMessage());
    }   
    }

    @Override
    public void deleteOperation2(String sid) {
    try{
       String query = "SELECT * FROM `staff` WHERE `Staff_ID` = "+sid;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){ 
       String query1 = "DELETE FROM `staff` WHERE `Staff_ID` = "+sid;
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1 == 1){
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Existing Staff ID " + sid + " has been deleted from the database.");
            a.showAndWait();
           System.out.println("The Staff Details for Staff ID : "+sid+" have been successfully delete from the database.");
       }else{
            System.out.println("Could not delete the Staff Details from the Database kindly try again.");
       }
       }else{
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Staff ID " + sid + " does not exist kindly try again with an existing Staff ID.");
            a.showAndWait();
            System.out.println("Could not find the Staff Details from the Database kindly try again with a different Staff ID.");
       }
       con.close();
       
        }catch(SQLException sqle){
        System.out.println("Staff Details not found, the following error occured: "+sqle.getMessage());
    }       
    }

    @Override
    public void updateOperation2(String sid1, String sfname, String slname, String sjobtype, String ssalary, String semail, String sphone, String sgender, String sstartshift, String sendshift) {
    try{
          
       String query = "SELECT * FROM `staff` WHERE `Staff_ID` = "+sid1;
       PreparedStatement pst;
       pst = con.prepareStatement(query);
       ResultSet rs = pst.executeQuery();
       
       if(rs.next()){   
       String query1 = "UPDATE `staff` SET `First_Name`='"+sfname+"',`Last_Name`='"+slname+"',`Job_Type`='"+sjobtype+"',`Salary`='"+ssalary+"',`Email_Address`='"+semail+"',`Phone_Number`='"+sphone+"',`Gender`='"+sgender+"',`Start_Shift`='"+sstartshift+"',`End_Shift`='"+sendshift+"' WHERE `Staff_ID`='"+sid1+"'";
       PreparedStatement pst1;
       pst1 = con.prepareStatement(query1);
       int rs1 = pst1.executeUpdate();
       
       if(rs1 == 1){
            a.setAlertType(Alert.AlertType.INFORMATION);
            a.setContentText("Existing Staff ID " + sid1 + " has been updated in the database.");
            a.showAndWait();
           System.out.println("The Staff Details for Staff ID : "+sid1+" have been successfully updated on the database.");
       }else{
            System.out.println("Could not delete the Staff Details from the Database kindly try again.");
       }
       
       con.close();
       
        }else{
            a.setAlertType(Alert.AlertType.ERROR);
            a.setContentText("Staff ID " + sid1 + " does not exist kindly try again with an existing Staff ID.");
            a.showAndWait();
            System.out.println("Could not find the Staff Details from the Database kindly try again with a different Staff ID.");
       }
      }catch(SQLException sqle){
        System.out.println("Connection to the Database is Unsuccessful due to: "+sqle.getMessage());
    }    
    }

    
}
